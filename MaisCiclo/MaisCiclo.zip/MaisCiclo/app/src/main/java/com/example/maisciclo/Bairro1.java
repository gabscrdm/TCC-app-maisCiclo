package com.example.maisciclo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Bairro1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_bairro1);
    }
}