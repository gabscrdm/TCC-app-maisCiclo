package com.example.maisciclo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Report extends AppCompatActivity {

    Button btnEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnEmail = (Button)findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                
            }
        });
    }
}